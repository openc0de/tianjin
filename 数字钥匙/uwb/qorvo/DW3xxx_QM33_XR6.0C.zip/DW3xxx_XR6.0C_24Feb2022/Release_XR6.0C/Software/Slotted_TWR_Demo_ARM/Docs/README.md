# Note:
This documentation based on the STM32F429_NUCLEO source code,
It will be the same for nRF52840_DK platform excluding folders structure and code build steps.

Build steps can be found in the relevant README files inside the target packages


/signed
17-Feb-2022
