Description:	DW3000 Release Pack 
Version:       6.0C
Release Date:  17th Feb 2021

--
Deliverable:

   - DecaRanging_5p02
  Issue:

   - In some machines, the application GUI freezes right after board set as "Tag".
  Fix/Workaround:

   - To perform any action after that, the application needs to be restarted.
     
      Despite the problem, the "Tag" still works and a second device set as "Anchor" can detect and ranging with it.

Murata 2AB 

- As the module has no built-in fixed antenna, the lookup tables to convert PDoA to AoA should be characterized by design

/signed
17-Feb-2021