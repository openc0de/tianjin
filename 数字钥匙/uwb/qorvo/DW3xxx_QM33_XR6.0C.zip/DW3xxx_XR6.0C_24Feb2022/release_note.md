# XR6.0C release note

DW3XXX MP/X0 Production Software Release:

Binary, sources, and documentation structured in an appropriate folders:

- DW3XXX DecaRanging PC application R5.02
- DW3XXX API (09.03.00) and Simple Examples package v6.0
- Slotted TWR-demo
- PDoA GUI (1.0)

Embedded applications support the following targets:

- ST NUCLEO-F429
- nRF52840-DK
- Murata 2AB

/signed
23-Feb-2022